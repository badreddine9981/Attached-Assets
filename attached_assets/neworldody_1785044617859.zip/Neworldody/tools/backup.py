#!/usr/bin/env python3
import shutil
from pathlib import Path
from datetime import datetime

PROJECT = Path.home() / "Neworldody"
BACKUPS = PROJECT / "backups"

def backup():
    BACKUPS.mkdir(exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = BACKUPS / f"neworldody_backup_{timestamp}"
    def ignore(path, names):
        return {"backups", "build", "__pycache__", ".git"}
    shutil.copytree(PROJECT, backup_path, ignore=ignore)
    print(f"✅ Backup: {backup_path}")

if __name__ == "__main__":
    backup()
