#!/usr/bin/env python3
import shutil
from pathlib import Path

PROJECT = Path.home() / "Neworldody"
WEBSITE = PROJECT / "website"
BUILD = PROJECT / "build"

def build():
    print("🔨 Building Neworldody...")
    
    # Clean old build
    if BUILD.exists():
        print("  🗑️  Cleaning old build...")
        shutil.rmtree(BUILD)
    
    # Create new build
    BUILD.mkdir(parents=True)
    print(f"  📁 Created: {BUILD}")
    
    # Copy directories
    for src_name in ["css", "js", "assets"]:
        src_path = WEBSITE / src_name
        if src_path.exists():
            dst_path = BUILD / src_name
            shutil.copytree(src_path, dst_path)
            print(f"  ✅ Copied: {src_name}/")
        else:
            print(f"  ⚠️  Missing: {src_name}/")
            dst_path = BUILD / src_name
            dst_path.mkdir(parents=True, exist_ok=True)
    
    # Copy files
    for file_name in ["index.html", "manifest.json", "sw.js"]:
        src = WEBSITE / file_name
        if src.exists():
            shutil.copy2(src, BUILD / file_name)
            print(f"  ✅ Copied: {file_name}")
        else:
            print(f"  ⚠️  Missing: {file_name}")
    
    # Copy data
    data_src = WEBSITE / "data"
    if data_src.exists():
        data_dst = BUILD / "data"
        shutil.copytree(data_src, data_dst)
        print(f"  ✅ Copied: data/")
    else:
        print(f"  ⚠️  Missing: data/")
        (BUILD / "data").mkdir(parents=True, exist_ok=True)
    
    print(f"\n✅ Build complete: {BUILD}")
    print(f"📊 Total items: {len(list(BUILD.rglob('*')))}")

if __name__ == "__main__":
    build()
