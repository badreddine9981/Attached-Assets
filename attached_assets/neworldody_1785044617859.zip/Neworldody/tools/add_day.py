#!/usr/bin/env python3
import sys, json
from pathlib import Path
from datetime import datetime

def add_day(day_num):
    data_dir = Path.home() / "Neworldody/website/data/days"
    data_dir.mkdir(parents=True, exist_ok=True)
    day_file = data_dir / f"day_{day_num:03d}.json"
    if day_file.exists():
        print(f"⚠️ Day {day_num} exists!")
        return
    template = {
        "day": day_num,
        "date_created": datetime.now().isoformat(),
        "title": f"Day {day_num}",
        "message": "",
        "wisdom": "",
        "tip": "",
        "space_fact": "",
        "star_of_day": "",
        "planet_focus": "",
        "timer_target": "",
        "unlocked": day_num == 1
    }
    day_file.write_text(json.dumps(template, indent=2, ensure_ascii=False))
    print(f"✅ Created: {day_file}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python add_day.py <day_number>")
        sys.exit(1)
    add_day(int(sys.argv[1]))
