#!/usr/bin/env python3
import shutil
from pathlib import Path

PROJECT = Path.home() / "Neworldody"
BUILD = PROJECT / "build"
DEPLOY = PROJECT / "deploy"

def prepare():
    if not BUILD.exists():
        print("❌ Run build.py first!")
        return
    if DEPLOY.exists():
        shutil.rmtree(DEPLOY)
    shutil.copytree(BUILD, DEPLOY)
    (DEPLOY / ".nojekyll").touch()
    print(f"✅ Deploy ready: {DEPLOY}")

if __name__ == "__main__":
    prepare()
