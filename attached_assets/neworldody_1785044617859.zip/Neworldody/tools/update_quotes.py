#!/usr/bin/env python3
import json, sys
from pathlib import Path

QUOTES = Path.home() / "Neworldody/website/data/quotes/quotes.json"

def add_quote(text, author="", category="general"):
    QUOTES.parent.mkdir(parents=True, exist_ok=True)
    quotes = []
    if QUOTES.exists():
        quotes = json.loads(QUOTES.read_text())
    quotes.append({"text": text, "author": author, "category": category, "id": len(quotes)+1})
    QUOTES.write_text(json.dumps(quotes, indent=2, ensure_ascii=False))
    print(f"✅ Quote added. Total: {len(quotes)}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python update_quotes.py 'Quote text' 'Author'")
        sys.exit(1)
    add_quote(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else "")
