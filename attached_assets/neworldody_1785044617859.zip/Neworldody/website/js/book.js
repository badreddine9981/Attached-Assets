const Book = {
    currentScreen: 'cover',
    currentDay: 1,
    
    init() {
        this.bindEvents();
        this.loadDay(1);
    },
    
    bindEvents() {
        const cover = document.getElementById('book-cover');
        const closeBtn = document.getElementById('close-btn');
        
        if (cover) {
            cover.addEventListener('click', () => this.openBook());
        }
        
        if (closeBtn) {
            closeBtn.addEventListener('click', () => this.closeBook());
        }
    },
    
    openBook() {
        const cover = document.getElementById('book-cover');
        const coverScreen = document.getElementById('cover-screen');
        
        // Animation
        cover.classList.add('opening');
        
        setTimeout(() => {
            coverScreen.classList.remove('active');
            coverScreen.classList.add('fade-out');
            
            setTimeout(() => {
                document.getElementById('book-screen').classList.add('active');
            }, 300);
        }, 1500);
    },
    
    closeBook() {
        const bookScreen = document.getElementById('book-screen');
        const timerScreen = document.getElementById('timer-screen');
        
        bookScreen.classList.remove('active');
        
        setTimeout(() => {
            timerScreen.classList.add('active');
            this.startTimer();
        }, 500);
    },
    
    async loadDay(dayNum) {
        try {
            const res = await fetch('data/days/day_' + String(dayNum).padStart(3, '0') + '.json');
            const data = res.ok ? await res.json() : this.defaultDay(dayNum);
            this.renderDay(data);
        } catch (e) {
            this.renderDay(this.defaultDay(dayNum));
        }
    },
    
    defaultDay(dayNum) {
        return {
            day: dayNum,
            title: 'اليوم ' + dayNum,
            message: 'أهلاً بك في يوم جديد من رحلتك.',
            wisdom: 'الحكمة ليست في كمية ما تعرف، بل في كيفية استخدام ما تعلمت.',
            wisdom_author: 'غوتاما بوذا',
            tip: 'خذ دقيقة واحدة للتنفس بعمق.'
        };
    },
    
    renderDay(data) {
        const setText = (id, text) => {
            const el = document.getElementById(id);
            if (el) el.textContent = text || '';
        };
        
        setText('page-day', this.toArabicNum(data.day));
        setText('page-title', data.title);
        setText('page-message', data.message);
        setText('page-wisdom', data.wisdom);
        setText('page-author', '— ' + (data.wisdom_author || ''));
        setText('page-tip', data.tip);
    },
    
    toArabicNum(num) {
        const arabic = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
        return String(num).split('').map(d => arabic[d] || d).join('');
    },
    
    startTimer() {
        const display = document.getElementById('countdown');
        if (!display) return;
        
        const update = () => {
            const now = new Date();
            const tomorrow = new Date(now);
            tomorrow.setDate(tomorrow.getDate() + 1);
            tomorrow.setHours(0, 0, 0, 0);
            
            const remaining = tomorrow - now;
            if (remaining <= 0) {
                display.textContent = '٠٠:٠٠:٠٠';
                return;
            }
            
            const h = Math.floor(remaining / 3600000);
            const m = Math.floor((remaining % 3600000) / 60000);
            const s = Math.floor((remaining % 60000) / 1000);
            
            display.textContent = 
                this.toArabicNum(h) + ':' +
                this.toArabicNum(m) + ':' +
                this.toArabicNum(s);
        };
        
        update();
        setInterval(update, 1000);
    }
};

document.addEventListener('DOMContentLoaded', () => Book.init());
