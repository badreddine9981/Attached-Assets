const Storage = {
    set(key, value) {
        try { localStorage.setItem(key, JSON.stringify(value)); return true; }
        catch (e) { console.error('Save failed:', e); return false; }
    },
    get(key, defaultValue = null) {
        try { const d = localStorage.getItem(key); return d ? JSON.parse(d) : defaultValue; }
        catch (e) { console.error('Load failed:', e); return defaultValue; }
    },
    remove(key) { localStorage.removeItem(key); },
    clearAll() { Object.values(CONFIG.STORAGE_KEYS).forEach(k => localStorage.removeItem(k)); },
    getProgress() {
        return this.get(CONFIG.STORAGE_KEYS.PROGRESS, {
            currentDay: 1, highestDay: 1, completedDays: [], startDate: new Date().toISOString()
        });
    },
    saveProgress(p) { return this.set(CONFIG.STORAGE_KEYS.PROGRESS, p); },
    unlockDay(dayNum) {
        const p = this.getProgress();
        if (!p.completedDays.includes(dayNum)) p.completedDays.push(dayNum);
        if (dayNum > p.highestDay) { p.highestDay = dayNum; p.currentDay = dayNum; }
        this.saveProgress(p); return p;
    },
    isDayUnlocked(dayNum) {
        if (dayNum === 1) return true;
        const p = this.getProgress();
        return p.completedDays.includes(dayNum - 1);
    },
    canUnlockNextDay() {
        const last = this.get(CONFIG.STORAGE_KEYS.LAST_VISIT);
        if (!last) return true;
        return (Date.now() - new Date(last).getTime()) >= CONFIG.MS_PER_DAY;
    },
    updateLastVisit() { this.set(CONFIG.STORAGE_KEYS.LAST_VISIT, new Date().toISOString()); }
};
window.Storage = Storage;
