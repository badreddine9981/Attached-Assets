const DayLoader = {
    currentDay: 1,
    async init() {
        const p = Storage.getProgress();
        this.currentDay = p.currentDay || 1;
        await this.loadDay(this.currentDay);
        this.updateProgressRing(); this.updateNavigation();
    },
    async loadDay(dayNum) {
        if (!Storage.isDayUnlocked(dayNum)) { this.showLocked(dayNum); return; }
        try {
            const res = await fetch(`data/days/day_${String(dayNum).padStart(3,'0')}.json`);
            let data = res.ok ? await res.json() : this.generateDefaultDay(dayNum);
            this.renderDay(data); this.currentDay = dayNum;
            const p = Storage.getProgress(); p.currentDay = dayNum; Storage.saveProgress(p);
        } catch (e) { console.error(e); this.renderDay(this.generateDefaultDay(dayNum)); }
    },
    generateDefaultDay(dayNum) {
        return {
            day: dayNum, title: `اليوم ${dayNum}`,
            message: "أهلاً بك في يوم جديد من رحلتك. كل يوم يحمل فرصاً جديدة للنمو والاكتشاف.",
            wisdom: "الحكمة ليست في كمية ما تعرف، بل في كيفية استخدام ما تعلمت.",
            wisdom_author: "غوتاما بوذا",
            tip: "خذ دقيقة واحدة اليوم للتنفس بعمق والشعور بالحاضر.",
            space_fact: "الضوء القادم من الشمس يستغرق 8 دقائق و20 ثانية ليصل إلى الأرض.",
            star_of_day: "سيريوس - ألمع نجم في سماء الليل",
            planet_focus: "المريخ - الكوكب الأحمر"
        };
    },
    renderDay(data) {
        const setText = (id, text) => { const el = document.getElementById(id); if (el) el.textContent = text || ''; };
        setText('day-counter', data.day);
        setText('day-title', data.title || `اليوم ${data.day}`);
        setText('daily-message', data.message);
        setText('daily-wisdom', data.wisdom);
        setText('wisdom-source', data.wisdom_author);
        setText('daily-tip', data.tip);
        setText('space-fact', data.space_fact);
        setText('star-of-day', data.star_of_day);
        setText('planet-focus', data.planet_focus);
        this.animateContent();
    },
    showLocked(dayNum) {
        const content = document.getElementById('day-content');
        if (!content) return;
        let overlay = content.querySelector('.locked-overlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.className = 'locked-overlay';
            overlay.innerHTML = `<div class="lock-icon">🔒</div><p>اليوم ${dayNum} مقفل</p><p>عد غداً لفتح يوم جديد</p>`;
            content.appendChild(overlay);
        }
    },
    updateProgressRing() {
        const p = Storage.getProgress(), pct = (p.highestDay / CONFIG.TOTAL_DAYS) * 100;
        const circle = document.getElementById('progress-circle');
        if (circle) circle.setAttribute('stroke-dasharray', `${pct}, 100`);
    },
    updateNavigation() {
        const prev = document.getElementById('prev-day'), next = document.getElementById('next-day');
        if (prev) prev.disabled = this.currentDay <= 1;
        const nextDay = this.currentDay + 1;
        if (next) next.disabled = !Storage.isDayUnlocked(nextDay) || nextDay > CONFIG.TOTAL_DAYS;
    },
    goToPrev() { if (this.currentDay > 1) { this.loadDay(this.currentDay - 1); this.updateNavigation(); } },
    goToNext() {
        const next = this.currentDay + 1;
        if (next <= CONFIG.TOTAL_DAYS && Storage.isDayUnlocked(next)) {
            this.loadDay(next); this.updateNavigation();
        }
    },
    animateContent() {
        document.querySelectorAll('.content-section > div, .space-section, .timer-section').forEach((el, i) => {
            el.style.animation = 'none'; el.offsetHeight;
            el.style.animation = `textReveal 0.5s ease ${i * 0.1}s forwards`;
            el.style.opacity = '0';
        });
    }
};
document.addEventListener('DOMContentLoaded', () => DayLoader.init());
