const Timer = {
    interval: null, targetTime: null,
    init() { this.calculateTarget(); this.start(); },
    calculateTarget() {
        const now = new Date(), tomorrow = new Date(now);
        tomorrow.setDate(tomorrow.getDate() + 1);
        tomorrow.setHours(0, 0, 0, 0);
        this.targetTime = tomorrow.getTime();
    },
    start() { this.update(); this.interval = setInterval(() => this.update(), 1000); },
    update() {
        const now = Date.now(), remaining = this.targetTime - now;
        const display = document.getElementById('countdown');
        if (!display) return;
        if (remaining <= 0) { display.textContent = '00:00:00'; this.onNewDay(); return; }
        const h = Math.floor(remaining / 3600000);
        const m = Math.floor((remaining % 3600000) / 60000);
        const s = Math.floor((remaining % 60000) / 1000);
        display.textContent = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
    },
    onNewDay() { this.calculateTarget(); if (Storage.canUnlockNextDay()) this.showNewDayNotification(); },
    showNewDayNotification() {
        const p = Storage.getProgress(), next = p.highestDay + 1;
        if (next <= CONFIG.TOTAL_DAYS) {
            console.log(`New day: ${next}`);
            const btn = document.getElementById('next-day');
            if (btn) { btn.classList.add('heartbeat'); btn.disabled = false; }
        }
    },
    stop() { if (this.interval) { clearInterval(this.interval); this.interval = null; } }
};
document.addEventListener('DOMContentLoaded', () => Timer.init());
