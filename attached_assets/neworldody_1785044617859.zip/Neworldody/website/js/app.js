const App = {
    initialized: false,
    init() {
        if (this.initialized) return;
        Storage.updateLastVisit();
        this.setupNavigation(); this.setupKeyboard();
        this.checkDayUnlock();
        this.initialized = true;
        console.log('Neworldody initialized');
    },
    setupNavigation() {
        const prev = document.getElementById('prev-day'), next = document.getElementById('next-day'), today = document.getElementById('today-btn');
        if (prev) prev.addEventListener('click', () => DayLoader.goToPrev());
        if (next) next.addEventListener('click', () => DayLoader.goToNext());
        if (today) today.addEventListener('click', () => { const p = Storage.getProgress(); DayLoader.loadDay(p.currentDay); });
    },
    setupKeyboard() {
        document.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowLeft') DayLoader.goToPrev();
            else if (e.key === 'ArrowRight') DayLoader.goToNext();
            else if (e.key === 'Home') { const p = Storage.getProgress(); DayLoader.loadDay(p.currentDay); }
        });
    },
    checkDayUnlock() {
        const p = Storage.getProgress(), next = p.highestDay + 1;
        if (next <= CONFIG.TOTAL_DAYS && Storage.canUnlockNextDay()) console.log(`Day ${next} available!`);
    },
    getStats() {
        const p = Storage.getProgress();
        return { currentDay: p.currentDay, totalDays: CONFIG.TOTAL_DAYS, completed: p.completedDays.length, progress: ((p.highestDay / CONFIG.TOTAL_DAYS) * 100).toFixed(1) + '%', startDate: p.startDate };
    }
};
document.addEventListener('DOMContentLoaded', () => App.init());
