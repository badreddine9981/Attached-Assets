const CONFIG = {
    APP_NAME: 'Neworldody',
    VERSION: '1.0.0',
    TOTAL_DAYS: 365,
    MS_PER_DAY: 86400000,
    STORAGE_KEYS: {
        PROGRESS: 'neworldody_progress',
        LAST_VISIT: 'neworldody_last_visit',
        SETTINGS: 'neworldody_settings',
        UNLOCKED_DAYS: 'neworldody_unlocked'
    },
    DEFAULTS: {
        theme: 'dark',
        notifications: true,
        fontSize: 'medium'
    },
    API: {
        NASA_APOD: 'https://api.nasa.gov/planetary/apod'
    }
};
window.CONFIG = CONFIG;
