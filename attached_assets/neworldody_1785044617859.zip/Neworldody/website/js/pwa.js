if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('sw.js')
            .then(r => console.log('SW registered:', r.scope))
            .catch(e => console.log('SW failed:', e));
    });
}
let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault(); deferredPrompt = e;
    const btn = document.getElementById('install-pwa');
    if (btn) {
        btn.style.display = 'block';
        btn.addEventListener('click', async () => {
            if (!deferredPrompt) return;
            deferredPrompt.prompt();
            const { outcome } = await deferredPrompt.userChoice;
            if (outcome === 'accepted') { console.log('App installed'); btn.style.display = 'none'; }
            deferredPrompt = null;
        });
    }
});
window.addEventListener('appinstalled', () => { console.log('Neworldody installed'); deferredPrompt = null; });
