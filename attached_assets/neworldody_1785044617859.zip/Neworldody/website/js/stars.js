const Stars = {
    container: null, starCount: 150,
    init() {
        this.container = document.getElementById('stars-container');
        if (!this.container) return;
        this.createStars(); this.createShootingStars();
    },
    createStars() {
        for (let i = 0; i < this.starCount; i++) {
            const star = document.createElement('div');
            star.className = 'star';
            const x = Math.random() * 100, y = Math.random() * 100;
            const size = Math.random() * 2.5 + 0.5;
            const duration = Math.random() * 4 + 2;
            const minOpacity = Math.random() * 0.5 + 0.2;
            star.style.cssText = `left:${x}%;top:${y}%;width:${size}px;height:${size}px;--duration:${duration}s;--min-opacity:${minOpacity};animation-delay:${Math.random()*5}s;`;
            this.container.appendChild(star);
        }
    },
    createShootingStars() {
        setInterval(() => { if (Math.random() > 0.7) this.spawnShootingStar(); }, 8000);
    },
    spawnShootingStar() {
        const star = document.createElement('div');
        star.className = 'shooting-star';
        const startY = Math.random() * 50, duration = Math.random() * 2 + 1.5;
        star.style.cssText = `top:${startY}%;left:-100px;animation-duration:${duration}s;`;
        this.container.appendChild(star);
        setTimeout(() => star.remove(), duration * 1000 + 100);
    }
};
document.addEventListener('DOMContentLoaded', () => Stars.init());
