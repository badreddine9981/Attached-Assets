const CACHE_NAME = 'neworldody-v1';
const STATIC_ASSETS = ['/','/index.html','/css/main.css','/css/animations.css','/js/config.js','/js/storage.js','/js/stars.js','/js/timer.js','/js/day-loader.js','/js/app.js','/js/pwa.js','/manifest.json'];

self.addEventListener('install', (e) => {
    e.waitUntil(caches.open(CACHE_NAME).then(c => c.addAll(STATIC_ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
    e.waitUntil(caches.keys().then(names => Promise.all(names.filter(n => n !== CACHE_NAME).map(n => caches.delete(n)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
    e.respondWith(caches.match(e.request).then(r => {
        if (r) return r;
        return fetch(e.request).then(nr => { if (nr && nr.status === 200) { const clone = nr.clone(); caches.open(CACHE_NAME).then(c => c.put(e.request, clone)); } return nr; });
    }).catch(() => { if (e.request.mode === 'navigate') return caches.match('/index.html'); }));
});
